from enum import Enum

class GrapeTypeEnum(str, Enum):
    viniferas = "Viníferas"
    americanas_hibridas = "Americanas e híbridas"
    uvas_mesa = "Uvas de mesa"
    sem_classificacao = "Sem classificação"
